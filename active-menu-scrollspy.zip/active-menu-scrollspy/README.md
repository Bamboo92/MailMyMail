## ScrollSpy
_jquery plugin_

### Install
```
composer require twg-group/jquery.scroll-spy
```

### Basic usage
```javascript
$('.content-wrapper').scrollSpy({
    target: $('.menu a'), // required
    activeClass: 'active', // defaults
    fixed: true // defaults
});
```
